import django_filters

from .models import *

class MissingPersonFilter(django_filters.FilterSet):
    class Meta:
        model = MissingPerson
        fields = ['state', 'municipio', 'date_and_time']