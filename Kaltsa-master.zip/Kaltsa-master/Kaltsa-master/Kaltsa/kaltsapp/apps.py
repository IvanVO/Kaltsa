from django.apps import AppConfig


class KaltsappConfig(AppConfig):
    name = 'kaltsapp'
